package core.runner;

import algs4.util.StopwatchCPU;
import core.problem.Problem;
import core.solver.algorithm.searcher.AbstractSearcher;
import core.solver.queue.Node;
import core.solver.algorithm.heuristic.Predictor;
import core.solver.queue.EvaluationType;
import core.solver.queue.Frontier;
import stud.g01.queue.PqFrontier;
import core.solver.algorithm.searcher.BestFirstSearcher;

import stud.g01.problem.npuzzle.PuzzleBoard;
import stud.g01.problem.npuzzle.NPuzzleProblem;
import stud.g01.problem.npuzzle.heuristic.ManhattanHeuristic;
import stud.g01.problem.npuzzle.heuristic.MisplacedHeuristic;
import dmodule.pattern.DisjointPDBPredictor;

import java.util.ArrayList;
import java.util.Deque;

public final class SearchTester {

    public static void main(String[] args) {
        System.out.println("=== 开始 A* 启发式函数对比 (3阶) ===");

        ArrayList<Problem> problems = new ArrayList<>();
        problems.add(createProblem(3, new int[]{5, 0, 8, 4, 2, 1, 7, 3, 6}));
        problems.add(createProblem(3, new int[]{6, 4, 7, 8, 5, 0, 3, 2, 1}));
        problems.add(createProblem(3, new int[]{8, 6, 7, 2, 5, 4, 3, 0, 1}));

        int[] goalTiles = {1, 2, 3, 4, 5, 6, 7, 8, 0};
        PuzzleBoard goalBoard = new PuzzleBoard(3, goalTiles);

        // 1. Hamming
        System.out.println("\n>>> 正在测试 [Hamming] (如果超过10秒没反应，请手动 Stop，跳过此项) <<<");
        runAStarOnly(problems, new MisplacedHeuristic(), "Hamming");

        // 2. Manhattan
        System.out.println("\n>>> 正在测试 [Manhattan] <<<");
        runAStarOnly(problems, new ManhattanHeuristic(), "Manhattan");

        // 3. PDB
        System.out.println("\n>>> 正在测试 [PDB] (正在建表，请稍候) <<<");
        runAStarOnly(problems, new DisjointPDBPredictor(goalBoard, false), "PDB");

        System.out.println("\n=== 全部测试结束 ===");
    }

    private static void runAStarOnly(ArrayList<Problem> problems, Predictor predictor, String name) {
        Frontier frontier = new PqFrontier(EvaluationType.FULL);
        AbstractSearcher astar = new BestFirstSearcher(frontier, predictor);

        for (int i = 0; i < problems.size(); i++) {
            Problem problem = problems.get(i);
            System.out.printf("[A* + %s] 案例 %d: ", name, i + 1);

            StopwatchCPU timer = new StopwatchCPU();
            Deque<Node> path = astar.search(problem);
            double time = timer.elapsedTime();

            if (path == null) {
                System.out.printf("失败 | 耗时: %.3fs | 扩展: %d%n", time, astar.nodesExpanded());
            } else {
                System.out.printf("成功 | 耗时: %.3fs | 扩展: %d%n", time, astar.nodesExpanded());
            }
        }
    }

    private static Problem createProblem(int size, int[] tiles) {
        PuzzleBoard initialBoard = new PuzzleBoard(size, tiles);
        int[] goalTiles = new int[size * size];
        for (int i = 0; i < size * size - 1; i++) {
            goalTiles[i] = i + 1;
        }
        goalTiles[size * size - 1] = 0;
        return new NPuzzleProblem(initialBoard, new PuzzleBoard(size, goalTiles));
    }
}
