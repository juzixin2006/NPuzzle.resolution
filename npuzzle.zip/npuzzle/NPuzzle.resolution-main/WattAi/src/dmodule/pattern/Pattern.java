package dmodule.pattern;

import java.util.HashSet;
import java.util.Set;

public class Pattern {
    /** 原始集合，保持与旧代码兼容。 */
    public final Set<Integer> tiles;

    /** 按升序排列的方块编号，编码/解码必须使用同一顺序。 */
    public final int[] order;

    public Pattern(Set<Integer> tiles) {
        if (tiles == null || tiles.isEmpty()) {
            throw new IllegalArgumentException("pattern 不能为空");
        }
        this.tiles = new HashSet<>(tiles);
        this.order = tiles.stream().mapToInt(Integer::intValue).sorted().toArray();
    }

    public Pattern(int... tiles) {
        this(toBeSet(tiles));
    }

    private static Set<Integer> toBeSet(int[] tiles) {
        Set<Integer> s = new HashSet<>();
        for (int t : tiles) s.add(t);
        return s;
    }

    public boolean containsTile(int tile) {
        return tiles.contains(tile);
    }

    public int size() {
        return order.length;
    }

    /**
     * 按棋盘规模选择划分：
     * <ul>
     *   <li>4x4：7-7-1（两个 7 方块表 + 1 个方块表）；</li>
     *   <li>3x3：4-4（两个 4 方块表）。</li>
     * </ul>
     * 这里的 7-7-1 / 4-4 都是“将牌划分”，PDB 状态只编码将牌位置，不含空格。
     */
    public static Pattern[] buildDisjointPatterns(int totalTiles) {
        if (totalTiles == 16) {
            return new Pattern[]{
                    new Pattern(1, 2, 3, 4, 5, 6, 7),
                    new Pattern(8, 9, 10, 11, 12, 13, 14),
                    new Pattern(15)
            };
        }
        if (totalTiles == 9) {
            return new Pattern[]{
                    new Pattern(1, 2, 3, 4),
                    new Pattern(5, 6, 7, 8)
            };
        }
        // 其他规模：每 4 个方块一组，保证表规模可控。
        java.util.List<Pattern> out = new java.util.ArrayList<>();
        for (int start = 1; start < totalTiles; start += 4) {
            int end = Math.min(start + 4, totalTiles);
            int[] group = new int[end - start];
            for (int i = start; i < end; i++) group[i - start] = i;
            out.add(new Pattern(group));
        }
        return out.toArray(new Pattern[0]);
    }

    /** 兼容旧调用：默认按 4x4 的 7-7-1 划分。 */
    public static Pattern[] buildDisjointPatterns() {
        return buildDisjointPatterns(16);
    }
}
