package dmodule.pattern;

import core.problem.State;
import core.solver.algorithm.heuristic.Predictor;
import stud.g01.problem.npuzzle.PuzzleBoard;

import java.util.Arrays;

/**
 * 7-7-1 additive disjoint PDB（不含空格）。
 *
 * <p>4x4 使用 {1..7}、{8..14}、{15} 三个 pattern；3x3 使用 {1..4}、{5..8}。
 * 每个 pattern 的状态只编码将牌位置，空格被当作任意可用空位，因此 PDB 是
 * 原问题的松弛，和仍然可采纳；每一步最多让一个 pattern 的距离增加 1。
 */
public class DisjointPDBPredictor implements Predictor {
    private final Pattern[] patterns;
    private final byte[][] pdbTables;
    private final PuzzleBoard goalBoard;
    private final int[] positionsScratch;

    public long totalExpandBFS = 0;
    public long totalTimeBFS = 0;

    public DisjointPDBPredictor(PuzzleBoard goalBoard, boolean useBiBFS) {
        if (goalBoard == null) {
            throw new IllegalArgumentException("goalBoard 不能为 null");
        }
        this.goalBoard = goalBoard;
        int totalTiles = goalBoard.getSize() * goalBoard.getSize();
        this.positionsScratch = new int[totalTiles];
        this.patterns = Pattern.buildDisjointPatterns(totalTiles);
        this.pdbTables = new byte[patterns.length][];

        PDBGenerator generator = new PDBGenerator();
        for (int i = 0; i < patterns.length; i++) {
            Pattern pat = patterns[i];
            PDBGenerator.GenResult res = useBiBFS
                    ? generator.generateBiBFS(pat, goalBoard)
                    : generator.generateBFS(pat, goalBoard);

            pdbTables[i] = res.pdbTable;
            totalExpandBFS += res.expandedNodes;
            totalTimeBFS += res.timeMs;
        }
        System.out.printf("[PDB] total: expanded=%d, time=%dms%n", totalExpandBFS, totalTimeBFS);
    }

    @Override
    public int heuristics(State state, State goal) {
        if (!(state instanceof PuzzleBoard board)) {
            return 0;
        }
        if (goal != null && !goal.equals(goalBoard)) {
            throw new IllegalArgumentException(
                    "DisjointPDBPredictor 是为构造时传入的 goalBoard 建表的，不能用于另一个目标状态");
        }
        int totalTiles = board.getSize() * board.getSize();
        if (totalTiles != positionsScratch.length) {
            return 0;
        }

        Arrays.fill(positionsScratch, -1);
        for (int pos = 0; pos < totalTiles; pos++) {
            int tile = board.getTile(pos);
            if (tile != 0 && tile < totalTiles) {
                positionsScratch[tile] = pos;
            }
        }

        int sum = 0;
        for (int i = 0; i < patterns.length; i++) {
            Pattern p = patterns[i];
            int key = 0;
            int shift = 0;
            boolean complete = true;
            for (int tile : p.order) {
                int pos = positionsScratch[tile];
                if (pos < 0) {
                    complete = false;
                    break;
                }
                key |= (pos & 0xF) << shift;
                shift += 4;
            }
            if (!complete) {
                continue;
            }
            byte[] table = pdbTables[i];
            if (key >= 0 && key < table.length) {
                byte value = table[key];
                if (value >= 0) {
                    sum += value;
                }
            }
        }
        return sum;
    }
}
