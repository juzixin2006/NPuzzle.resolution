package dmodule.pattern;

import stud.g01.problem.npuzzle.PuzzleBoard;

import java.util.Arrays;

/**
 * 生成“不含空格”的 additive PDB。
 *
 * <p>状态只编码 pattern 中 k 个将牌的位置，共 totalTiles P k 个：
 * <ul>
 *   <li>7 方块：16P7 = 57,657,600；</li>
 *   <li>4 方块：16P4 = 43,680；</li>
 *   <li>1 方块：16。</li>
 * </ul>
 * 状态键就是这些位置拼成的 4-bit 字段，因此可以直接作为表下标：
 * 7 方块表 2^28 = 268,435,456 个槽（byte），4 方块表 65,536 个槽。
 *
 * <p>这里故意不编码空格：空格被视为“任意可用的空位”，于是每一步
 * 只可能移动一个将牌、代价为 1；这是原问题的松弛，所以 PDB 值仍然可采纳。
 * 所有边代价都为 1，普通 FIFO BFS 即可正确求最短路。
 */
public class PDBGenerator {

    public static class GenResult {
        public final byte[] pdbTable;
        public final long expandedNodes;
        public final long timeMs;

        public GenResult(byte[] pdbTable, long expandedNodes, long timeMs) {
            this.pdbTable = pdbTable;
            this.expandedNodes = expandedNodes;
            this.timeMs = timeMs;
        }
    }

    private static final int[] DR = {-1, 1, 0, 0};
    private static final int[] DC = {0, 0, -1, 1};

    public GenResult generateBFS(Pattern pattern, PuzzleBoard goalBoard) {
        long startNanos = System.nanoTime();

        int size = goalBoard.getSize();
        int totalTiles = size * size;
        int k = pattern.order.length;
        if (k == 0) {
            return new GenResult(new byte[]{0}, 0, 0);
        }
        if (k > 7) {
            throw new IllegalArgumentException("最多支持 7 个方块的 pattern: " + pattern.tiles);
        }

        long stateCount = 1;
        for (int i = 0; i < k; i++) {
            stateCount *= (totalTiles - i);
        }
        if (stateCount > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("pattern 状态数过大: " + stateCount);
        }

        int tableSize = 1 << (4 * k);
        byte[] dist = new byte[tableSize];
        Arrays.fill(dist, (byte) -1);

        int[] goalPositions = new int[totalTiles];
        Arrays.fill(goalPositions, -1);
        for (int pos = 0; pos < totalTiles; pos++) {
            int tile = goalBoard.getTile(pos);
            if (tile != 0 && pattern.containsTile(tile)) {
                goalPositions[tile] = pos;
            }
        }
        for (int tile : pattern.order) {
            if (goalPositions[tile] < 0) {
                throw new IllegalArgumentException("目标棋盘中缺少 pattern 方块 " + tile);
            }
        }

        int startKey = keyOf(pattern, goalPositions);
        dist[startKey] = 0;

        int[] queue = new int[(int) stateCount];
        int head = 0;
        int tail = 0;
        queue[tail++] = startKey;

        int[] positions = new int[k];
        long reached = 0;
        int maxDist = 0;

        while (head < tail) {
            int key = queue[head++];
            int curDist = dist[key] & 0xFF;
            int nextDist = curDist + 1;
            if (nextDist > 127) {
                throw new IllegalStateException("PDB 距离超过 byte 上限: " + nextDist);
            }
            if (curDist > maxDist) maxDist = curDist;

            int occupied = 0;
            int temp = key;
            for (int i = 0; i < k; i++) {
                positions[i] = temp & 0xF;
                temp >>>= 4;
                occupied |= 1 << positions[i];
            }

            for (int i = 0; i < k; i++) {
                int oldPos = positions[i];
                int r = oldPos / size;
                int c = oldPos % size;
                for (int d = 0; d < 4; d++) {
                    int nr = r + DR[d];
                    int nc = c + DC[d];
                    if (nr < 0 || nr >= size || nc < 0 || nc >= size) {
                        continue;
                    }
                    int dest = nr * size + nc;
                    if ((occupied & (1 << dest)) != 0) {
                        continue;
                    }
                    int nextKey = key + ((dest - oldPos) << (4 * i));
                    if (dist[nextKey] == -1) {
                        dist[nextKey] = (byte) nextDist;
                        queue[tail++] = nextKey;
                    }
                }
            }
            reached++;
        }

        if (reached != stateCount) {
            System.out.printf("[PDB] warning: pattern %s reached=%d expected=%d%n",
                    Arrays.toString(pattern.order), reached, stateCount);
        }

        long costMs = (System.nanoTime() - startNanos) / 1_000_000;
        System.out.printf("[PDB] pattern %s states=%d max=%d time=%dms%n",
                Arrays.toString(pattern.order), reached, maxDist, costMs);
        return new GenResult(dist, reached, costMs);
    }

    /** 保持接口兼容；不含空格的 PDB 不需要双向 BFS。 */
    public GenResult generateBiBFS(Pattern pattern, PuzzleBoard goalBoard) {
        return generateBFS(pattern, goalBoard);
    }

    private static int keyOf(Pattern pattern, int[] positionsByTile) {
        int key = 0;
        int shift = 0;
        for (int tile : pattern.order) {
            key |= (positionsByTile[tile] & 0xF) << shift;
            shift += 4;
        }
        return key;
    }
}
