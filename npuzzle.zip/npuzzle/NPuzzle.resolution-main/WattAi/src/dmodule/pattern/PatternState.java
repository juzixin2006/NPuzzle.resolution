package dmodule.pattern;

import stud.g01.problem.npuzzle.PuzzleBoard;

import java.util.Arrays;

/**
 * 将一个 pattern 在棋盘上的投影压缩成一个 long。
 *
 * <p>编码格式（从低位到高位）：
 * <pre>
 *   bits 0..3    : 空格位置
 *   bits 4..7    : pattern.order[k-1] 的位置
 *   ...
 *   bits 4k..4k+3: pattern.order[0] 的位置
 * </pre>
 * 也就是说，先按 order 升序依次左移，最后再把空格放到最低 4 位。
 * 解码时必须使用同一个 k 和同一个 order，方块身份才不会错位。
 */
public final class PatternState {
    public final long key;
    public final int blank;

    public PatternState(PuzzleBoard board, Pattern pattern) {
        int total = board.getSize() * board.getSize();
        int[] positions = new int[total];
        Arrays.fill(positions, -1);
        for (int pos = 0; pos < total; pos++) {
            int tile = board.getTile(pos);
            if (tile != 0 && pattern.containsTile(tile)) {
                positions[tile] = pos;
            }
        }
        this.blank = board.getBlankIndex();
        this.key = encode(pattern, positions, blank);
    }

    /** 先按 pattern.order 的顺序编码方块，最后编码空格。 */
    public static long encode(Pattern pattern, int[] positionsByTile, int blank) {
        long key = 0;
        for (int tile : pattern.order) {
            key = (key << 4) | (positionsByTile[tile] & 0xFL);
        }
        return (key << 4) | (blank & 0xFL);
    }

    /**
     * 兼容旧接口：positionsByTile 中只有当前 pattern 的方块位置非负，
     * 因此按 tile 编号升序追加 nibble 与 pattern.order 的顺序一致。
     */
    public static long encode(int[] positionsByTile, int blank) {
        long key = 0;
        for (int i = 1; i < positionsByTile.length; i++) {
            if (positionsByTile[i] >= 0) {
                key = (key << 4) | (positionsByTile[i] & 0xFL);
            }
        }
        return (key << 4) | (blank & 0xFL);
    }

    public static int blank(long key) {
        return (int) (key & 0xFL);
    }

    /** 第 index 个 pattern 方块（pattern.order[index]）的位置；k = pattern.size()。 */
    public static int position(long key, int k, int index) {
        return (int) ((key >>> (4 * (k - index))) & 0xFL);
    }
}
