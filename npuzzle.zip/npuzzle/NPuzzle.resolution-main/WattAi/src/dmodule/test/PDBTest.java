package dmodule.test;

import core.solver.algorithm.heuristic.Predictor;
import dmodule.pattern.DisjointPDBPredictor;
import stud.g01.problem.npuzzle.PuzzleBoard;
import stud.g01.problem.npuzzle.heuristic.ManhattanHeuristic;

import java.util.*;

/**
 * 7-7-1 PDB 的独立测试入口。
 *
 * <p>运行方式（IDEA）：右键本文件 -> Run 'PDBTest.main()'，
 * VM options 建议加 -Xmx3g。</p>
 *
 * <p>命令行：
 * <pre>
 * cd NPuzzle.resolution-main
 * $sources = @(Get-ChildItem ./WattAi/src -Recurse -Filter '*.java' | ForEach-Object FullName)
 * javac -encoding UTF-8 -d ./out/cli @sources
 * java -Xmx3g -cp ./out/cli dmodule.test.PDBTest 1000000
 * </pre>
 * 参数是 A* 的扩展上限，默认 1,000,000。</p>
 */
public class PDBTest {

    private static final int[] GOAL = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0};
    private static final int[] DR = {-1, 1, 0, 0};
    private static final int[] DC = {0, 0, -1, 1};

    private static final class ANode implements Comparable<ANode> {
        final PuzzleBoard state;
        final ANode parent;
        final int g;
        final int h;

        ANode(PuzzleBoard state, ANode parent, int g, int h) {
            this.state = state;
            this.parent = parent;
            this.g = g;
            this.h = h;
        }

        int f() {
            return g + h;
        }

        @Override
        public int compareTo(ANode other) {
            if (f() != other.f()) {
                return Integer.compare(f(), other.f());
            }
            return Integer.compare(h, other.h);
        }
    }

    public static void main(String[] args) {
        int cap = args.length > 0 ? Integer.parseInt(args[0]) : 1_000_000;

        PuzzleBoard goal = new PuzzleBoard(4, GOAL);
        System.out.println("正在生成 7-7-1 PDB（约 30 秒；如 OOM 请设置 -Xmx3g 或 -Xmx4g）...");
        long t0 = System.currentTimeMillis();
        DisjointPDBPredictor pdb = new DisjointPDBPredictor(goal, false);
        long buildMs = System.currentTimeMillis() - t0;
        System.out.printf("PDB 构建完成，耗时 %d ms%n%n", buildMs);

        Predictor manhattan = new ManhattanHeuristic();

        int[][] states = {
                GOAL.clone(),
                oneMoveFromGoal(),
                {8, 6, 7, 2, 5, 4, 3, 0, 1, 9, 10, 11, 12, 13, 14, 15},
                {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 1, 2, 0}
        };
        String[] names = {"目标状态", "目标走一步", "random 样例", "hard 样例"};

        System.out.println("=== 启发值 ===");
        System.out.printf("%-12s %8s %12s%n", "状态", "PDB h", "Manhattan");
        for (int i = 0; i < states.length; i++) {
            PuzzleBoard board = new PuzzleBoard(4, states[i]);
            System.out.printf("%-12s %8d %12d%n",
                    names[i],
                    pdb.heuristics(board, goal),
                    manhattan.heuristics(board, goal));
        }

        System.out.printf("%n=== A* 对比（扩展上限 %d）===%n", cap);
        for (int i = 2; i < states.length; i++) {
            System.out.println("--- " + names[i] + " ---");
            for (Predictor predictor : new Predictor[]{manhattan, pdb}) {
                long start = System.currentTimeMillis();
                SearchResult result = aStar(new PuzzleBoard(4, states[i]), goal, predictor, cap);
                long ms = System.currentTimeMillis() - start;
                System.out.printf("  %-22s 解长=%d, 扩展=%d, 耗时=%dms%s%n",
                        predictor.getClass().getSimpleName(),
                        result.length,
                        result.expanded,
                        ms,
                        result.length < 0 ? "（达到上限，强停）" : "");
            }
        }
    }

    private static int[] oneMoveFromGoal() {
        int[] tiles = GOAL.clone();
        tiles[15] = tiles[11];
        tiles[11] = 0;
        return tiles;
    }

    private static SearchResult aStar(PuzzleBoard start, PuzzleBoard goal, Predictor predictor, int cap) {
        PriorityQueue<ANode> open = new PriorityQueue<>();
        Set<PuzzleBoard> closed = new HashSet<>();

        open.add(new ANode(start, null, 0, predictor.heuristics(start, goal)));
        int expanded = 0;

        while (!open.isEmpty()) {
            ANode current = open.poll();
            if (!closed.add(current.state)) {
                continue;
            }
            expanded++;

            if (current.state.equals(goal)) {
                int length = 0;
                for (ANode node = current; node.parent != null; node = node.parent) {
                    length++;
                }
                return new SearchResult(length, expanded);
            }

            if (expanded >= cap) {
                return new SearchResult(-1, expanded);
            }

            for (PuzzleBoard next : neighbors(current.state)) {
                if (!closed.contains(next)) {
                    open.add(new ANode(next, current, current.g + 1,
                            predictor.heuristics(next, goal)));
                }
            }
        }
        return new SearchResult(-2, expanded);
    }

    private static List<PuzzleBoard> neighbors(PuzzleBoard board) {
        int blank = board.getBlankIndex();
        int r = blank / 4;
        int c = blank % 4;
        int[] tiles = board.getTilesCopy();
        List<PuzzleBoard> result = new ArrayList<>(4);
        for (int d = 0; d < 4; d++) {
            int nr = r + DR[d];
            int nc = c + DC[d];
            if (nr < 0 || nr >= 4 || nc < 0 || nc >= 4) {
                continue;
            }
            int nextBlank = nr * 4 + nc;
            int[] nextTiles = tiles.clone();
            nextTiles[blank] = nextTiles[nextBlank];
            nextTiles[nextBlank] = 0;
            result.add(new PuzzleBoard(4, nextTiles));
        }
        return result;
    }

    private static final class SearchResult {
        final int length;
        final int expanded;

        SearchResult(int length, int expanded) {
            this.length = length;
            this.expanded = expanded;
        }
    }
}
