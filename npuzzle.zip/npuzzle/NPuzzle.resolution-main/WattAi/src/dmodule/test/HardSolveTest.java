package dmodule.test;

import dmodule.pattern.DisjointPDBPredictor;
import stud.g01.problem.npuzzle.PuzzleBoard;

import java.util.*;

/**
 * hard 样例的 Weighted A* 测试入口。
 *
 * <p>放到 WattAi/src/dmodule/test/ 下，IDEA 右键运行，
 * VM options 加 -Xmx3g。</p>
 *
 * <p>命令行：</p>
 * <pre>
 * cd NPuzzle.resolution-main
 * $sources = @(Get-ChildItem ./WattAi/src -Recurse -Filter '*.java' | ForEach-Object FullName)
 * javac -encoding UTF-8 -d ./out/cli @sources
 * java -Xmx3g -cp ./out/cli dmodule.test.HardSolveTest 1.2 3000000
 * </pre>
 *
 * 参数 1：weight（默认 1.2）；参数 2：扩展上限（默认 3,000,000）。
 */
public class HardSolveTest {

    private static final int[] GOAL = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0};
    private static final int[] HARD = {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 1, 2, 0};
    private static final int[] DR = {-1, 1, 0, 0};
    private static final int[] DC = {0, 0, -1, 1};

    private static DisjointPDBPredictor pdb;
    private static PuzzleBoard goal;
    private static double weight = 1.2;

    private static final class Node implements Comparable<Node> {
        final int[] tiles;
        final Node parent;
        final int g;
        final int h;
        final int blank;

        Node(int[] tiles, Node parent, int g, int h, int blank) {
            this.tiles = tiles;
            this.parent = parent;
            this.g = g;
            this.h = h;
            this.blank = blank;
        }

        int f() {
            return g + (int) Math.round(weight * h);
        }

        @Override
        public int compareTo(Node other) {
            if (f() != other.f()) {
                return Integer.compare(f(), other.f());
            }
            return Integer.compare(h, other.h);
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Node n && Arrays.equals(tiles, n.tiles);
        }

        @Override
        public int hashCode() {
            return Arrays.hashCode(tiles);
        }
    }

    public static void main(String[] args) {
        weight = args.length > 0 ? Double.parseDouble(args[0]) : 1.2;
        int cap = args.length > 1 ? Integer.parseInt(args[1]) : 3_000_000;

        goal = new PuzzleBoard(4, GOAL);
        System.out.println("正在生成 7-7-1 PDB（约 30 秒；如 OOM 请用 -Xmx3g 或 -Xmx4g）...");
        long t0 = System.currentTimeMillis();
        pdb = new DisjointPDBPredictor(goal, false);
        System.out.printf("PDB 构建完成：%d ms%n%n", System.currentTimeMillis() - t0);

        int m = manhattan(HARD);
        int lc = linearConflict(HARD);
        int p = pdb.heuristics(new PuzzleBoard(4, HARD), goal);
        int h = Math.max(p, m + 2 * lc);

        System.out.printf("hard: PDB=%d, Manhattan=%d, LC=%d, Manhattan+2LC=%d, hybrid h=%d%n",
                p, m, lc, m + 2 * lc, h);
        System.out.printf("Weighted A*: weight=%.2f, cap=%d%n", weight, cap);

        long start = System.currentTimeMillis();
        Result result = search(HARD, cap);
        long ms = System.currentTimeMillis() - start;

        if (result.length >= 0) {
            System.out.printf("结果：成功，解长=%d，扩展=%d，耗时=%dms%n",
                    result.length, result.expanded, ms);
            System.out.println("提示：该样例的最优解是 70 步；W=1.2 时返回的 70 步就是最优解。");
        } else {
            System.out.printf("结果：达到扩展上限 %d，强停；扩展=%d，耗时=%dms%n",
                    cap, result.expanded, ms);
        }
    }

    private static Result search(int[] startTiles, int cap) {
        PriorityQueue<Node> open = new PriorityQueue<>();
        Set<Node> closed = new HashSet<>();

        open.add(new Node(startTiles.clone(), null, 0, h(startTiles), findBlank(startTiles)));
        int expanded = 0;

        while (!open.isEmpty()) {
            Node current = open.poll();
            if (!closed.add(current)) {
                continue;
            }
            expanded++;

            if (Arrays.equals(current.tiles, GOAL)) {
                int length = 0;
                for (Node n = current; n.parent != null; n = n.parent) {
                    length++;
                }
                return new Result(length, expanded);
            }

            if (expanded >= cap) {
                return new Result(-1, expanded);
            }

            int r = current.blank / 4;
            int c = current.blank % 4;
            for (int d = 0; d < 4; d++) {
                int nr = r + DR[d];
                int nc = c + DC[d];
                if (nr < 0 || nr >= 4 || nc < 0 || nc >= 4) {
                    continue;
                }
                int nextBlank = nr * 4 + nc;
                int[] nextTiles = current.tiles.clone();
                nextTiles[current.blank] = nextTiles[nextBlank];
                nextTiles[nextBlank] = 0;
                open.add(new Node(nextTiles, current, current.g + 1,
                        h(nextTiles), nextBlank));
            }
        }
        return new Result(-2, expanded);
    }

    private static int h(int[] tiles) {
        int pdbH = pdb.heuristics(new PuzzleBoard(4, tiles), goal);
        int lcH = manhattan(tiles) + 2 * linearConflict(tiles);
        return Math.max(pdbH, lcH);
    }

    private static int manhattan(int[] tiles) {
        int distance = 0;
        for (int i = 0; i < 16; i++) {
            int tile = tiles[i];
            if (tile == 0) {
                continue;
            }
            int target = tile - 1;
            distance += Math.abs(i / 4 - target / 4) + Math.abs(i % 4 - target % 4);
        }
        return distance;
    }

    /**
     * 线性冲突：同一行/列中两个都在目标行/列、但前后顺序相反的方块，
     * 至少需要多绕 2 步。这里返回冲突对数。
     */
    private static int linearConflict(int[] tiles) {
        int conflicts = 0;

        for (int r = 0; r < 4; r++) {
            for (int a = 0; a < 4; a++) {
                int va = tiles[r * 4 + a];
                if (va == 0 || va / 4 != r) {
                    continue;
                }
                for (int b = a + 1; b < 4; b++) {
                    int vb = tiles[r * 4 + b];
                    if (vb == 0 || vb / 4 != r) {
                        continue;
                    }
                    if ((va - 1) % 4 > (vb - 1) % 4) {
                        conflicts++;
                    }
                }
            }
        }

        for (int c = 0; c < 4; c++) {
            for (int a = 0; a < 4; a++) {
                int va = tiles[a * 4 + c];
                if (va == 0 || (va - 1) % 4 != c) {
                    continue;
                }
                for (int b = a + 1; b < 4; b++) {
                    int vb = tiles[b * 4 + c];
                    if (vb == 0 || (vb - 1) % 4 != c) {
                        continue;
                    }
                    if ((va - 1) / 4 > (vb - 1) / 4) {
                        conflicts++;
                    }
                }
            }
        }

        return conflicts;
    }

    private static int findBlank(int[] tiles) {
        for (int i = 0; i < 16; i++) {
            if (tiles[i] == 0) {
                return i;
            }
        }
        return -1;
    }

    private static final class Result {
        final int length;
        final int expanded;

        Result(int length, int expanded) {
            this.length = length;
            this.expanded = expanded;
        }
    }
}
